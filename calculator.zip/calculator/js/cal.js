var db = 0;
var dis = document.getElementById("display");
var oper;
var dis2 = document.getElementById("display1");
let db2 = 0;
var dis3 = document.getElementById("display2");

const bt1 = () => {
  db = db * 10;
  db = db + 1;
  document.getElementById("display").innerHTML = db;
};

const bt2 = () => {
  db = db * 10;
  db = db + 2;
  dis.innerHTML = db;
};
const bt3 = () => {
  db = db * 10;
  db = db + 3;
  dis.innerHTML = db;
};
const bt4 = () => {
  db = db * 10;
  db = db + 4;
  dis.innerHTML = db;
};
const bt5 = () => {
  db = db * 10;
  db = db + 5;
  dis.innerHTML = db;
};
const bt6 = () => {
  db = db * 10;
  db = db + 6;
  dis.innerHTML = db;
};
const bt7 = () => {
  db = db * 10;
  db = db + 7;
  dis.innerHTML = db;
};
const bt8 = () => {
  db = db * 10;
  db = db + 8;
  dis.innerHTML = db;
};
const bt9 = () => {
  db = db * 10;
  db = db + 9;
  dis.innerHTML = db;
};
const bt0 = () => {
  db = db * 10;
  db = db + 0;
  dis.innerHTML = db;
};
const btmod = () => {
  oper = "mod";
  db2 = db;
  db = 0;
  dis.innerHTML = db;
  dis2.innerHTML = db2;
  dis3.innerHTML = "%";
};
const btadd = () => {
  oper = "add";
  db2 = db;
  db = 0;
  dis.innerHTML = db;
  dis2.innerHTML = db2;
  dis3.innerHTML = "+";
};
const btsub = () => {
  oper = "sub";
  db2 = db;
  db = 0;
  dis.innerHTML = db;
  dis2.innerHTML = db2;
  dis3.innerHTML = "-";
};
const btmul = () => {
  oper = "mul";
  db2 = db;
  db = 0;
  dis.innerHTML = db;
  dis2.innerHTML = db2;
  dis3.innerHTML = "*";
};
const btdiv = () => {
  oper = "div";
  db2 = db;
  db = 0;
  dis.innerHTML = db;
  dis2.innerHTML = db2;
  dis3.innerHTML = "/";
};
const btans = () => {
  opr();
  dis.innerHTML = db;
  dis2.innerHTML = db2;
};
const opr = () => {
  console.log(oper);
  switch (oper) {
    case "mod": {
      db = db % db2;
      dis.innerHTML = db;
      dis2.innerHTML = db2;

      break;
    }
    case "add": {
      db = db2 + db;
      dis.innerHTML = db;
      dis2.innerHTML = db2;

      break;
    }
    case "sub": {
      db = db2 - db;
      dis.innerHTML = db;
      dis2.innerHTML = db2;

      break;
    }
    case "mul": {
      db = db2 * db;
      dis.innerHTML = db;
      dis2.innerHTML = db2;

      break;
    }
    case "div": {
      db = db2 / db;
      dis.innerHTML = db;
      dis2.innerHTML = db2;

      break;
    }
  }
};

let a=document.getElementsByTagName("button")
console.log(a);
